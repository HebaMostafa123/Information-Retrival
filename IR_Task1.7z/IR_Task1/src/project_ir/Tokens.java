/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_ir;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author esraa
 */
public class Tokens {
    public String name;
      public int  position;
     //public ArrayList<HashMap> data=new ArrayList<HashMap>();
     public HashMap<String, ArrayList<Integer>> hmap;
    //public ArrayList<Integer> position;
    public Tokens(){
        //position=new ArrayList<Integer>();
        hmap = new HashMap<String,ArrayList<Integer>>();
                   }
   
    public void Add_inHAsh(String docname,int pos){
           if(hmap.containsKey(docname)){
           ArrayList<Integer> positio= hmap.get(docname);
           positio.add(pos);
           hmap.put(docname, positio);
           }
        else{
        ArrayList<Integer> post =new ArrayList<Integer>();
        post.add(pos);
        hmap.put(docname,post);
        
        }
        
    }
    
}
