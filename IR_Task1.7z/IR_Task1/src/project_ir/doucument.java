/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_ir;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

/**
 *
 * @author esraa
 */
public class doucument {
    public static ArrayList<doucument> data=new ArrayList<doucument>();
    public String name;
    public String content;
    public   Boolean add_doc(doucument doc){
    return data.add(doc);
    }
    public  static void  read_files(File files []){
        for (File doc:files){
           // System.out.println(doc);
        doucument d=new doucument();
        d.name=doc.getName();
        d.content="";
        try{
        BufferedReader br = new BufferedReader(new FileReader(doc));
        String line=" ";
        while((line=br.readLine())!=null){
           // System.out.println(line); 
        d.content+=line;
        d.content+=" ";
       line=" ";
        //System.out.println(doc+d.content+"========"+line);
       
        }
         d.add_doc(d);
            
        br.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        
        }
        System.out.println("==============docs============");
        for ( doucument item : doucument.data) {
          //String result =item.content.replaceAll("[\\t\\n\\r]+"," ");
          System.out.println(item.name+"\n"+item.content);
          System.out.println("----------------------------");
           }
        
    }
    
}
