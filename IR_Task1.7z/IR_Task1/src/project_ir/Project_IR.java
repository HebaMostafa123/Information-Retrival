package project_ir;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import static project_ir.doucument.data;
public class Project_IR {

    /**
     * @param args the command line arguments
     */
    
    
     public static void main(String[] args) throws IOException {
       ArrayList<String> documents=new ArrayList<String>();
       documents.add("esraa.txt");
       documents.add("eman.txt");
       documents.add("aml.txt");
       documents.add("asmaa.txt");
       //doucument.read_files(documents);
      ArrayList<Tokens> alltokens=PositionalIndex.Positional_index(doucument.data);
       PositionalIndex.print_display(alltokens);
        ArrayList<Tokens> input= PositionalIndex.display_postional_index("rise in  july",alltokens);//return data of query
        PositionalIndex.print_display(input);
        ArrayList<String> r=PositionalIndex.match_query(input);//return shared document
        if(r.isEmpty()){System.out.println("not match ");}
        else{
            System.out.println("matched in  ");
        for(String s:r){
            System.out.println(s);
        
        }
        
        }
       
        
        
        
       
               
               
       
    }
    
}
