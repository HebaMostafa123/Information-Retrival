package project_ir;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class PositionalIndex {
    public static ArrayList<Tokens> Positional_index(ArrayList<doucument> alldoc){//retutn documents as token have pos and key
        ArrayList<Tokens> alltokens=new ArrayList<Tokens>();
        for ( doucument item : alldoc) {
            String result=item.content.replaceAll("[\\t\\n\\r]+"," ");
            result =result.replaceAll("[^a-zA-Z0-9\\s+]", " ");
            //System.out.println(result);
            String[] parts = result.split("\\s+");
            Integer pos=0;
            int flag=0;
            for(String part: parts){
                 //System.out.println(part);
                for(Tokens token :alltokens)
                {
                if (token.name.equals(part)){
                    
                     token.Add_inHAsh(item.name,pos);
                    // System.out.println(pos+item.name);
                     flag++;
                     pos++;
                     break;
                }
              
                }
                if (flag==0){
                
                Tokens Tok=new Tokens();
                Tok.name=part;
                Tok.Add_inHAsh(item.name,pos);
                //System.out.println(pos+item.name);
                    //System.out.println("ok");
                alltokens.add(Tok);
                pos++;
                }
                flag=0;
            }
        } 
       /* for(Tokens token :alltokens)
                {
                   System.out.println(token.name);
                   //System.out.println("jjjjj"+token.hmap.values()+"jjjj");
                   for(String key:token.hmap.keySet()){
                      System.out.println(key+"  "+token.hmap.get(key)); 
                   
                   }
                     
                }*/
        return alltokens;
     
    }
    
     public static ArrayList<Tokens> display_postional_index(String query,ArrayList<Tokens> alltokens){
        // determine special character
         query=query.replaceAll("[^a-zA-Z\\s+]", " ");
         //System.out.println(query);
         String parts[]=query.split("\\s+");
         ArrayList<Tokens> input=new ArrayList<Tokens>();
         int po=0;
         for(String part :parts){
            
             for(Tokens token :alltokens)
                {
                if (token.name.equals(part)){
                    token.position=po;
                    //System.out.println(token.name+token.position);
                    input.add(token);
                    po++;
                    break;
                    
                }
                    
                     
                }
             
         
         }
         
      return input; 
    }
     
     public static ArrayList<String> match_query(ArrayList<Tokens> input){
       Set<String> inter=new HashSet<String>();
       for(int i=0;i<input.size();i++)
                {if(i==0){
                   //get all key of first word in query
                    Set<String>s1=input.get(i).hmap.keySet();
                   //to make intialize
                    inter=new HashSet<String>(s1);
                   
                    }
                   else{//to get shared document between input 
                       inter.retainAll(input.get(i).hmap.keySet());
                      }
                    //System.out.println(input.get(i).name+input.get(i).hmap.keySet());} }
                }
        //System.out.println(inter);
       ArrayList<String> result=new ArrayList<String>();
        for(String k:inter){
          int ok=0;
          ArrayList<Integer> firstposition = input.get(0).hmap.get(k);
          Set set = new HashSet(firstposition);//convert arraylist to set
          for(int j=1;j<input.size();j++){
          ArrayList<Integer> otherposition = input.get(j).hmap.get(k);
          Set<Integer> newo=new HashSet<Integer>();
          for(int other:otherposition){
              other=other-j;
              newo.add(other);//add in list
              }
             newo.retainAll(set);
             if(newo.isEmpty()){//to check if there are inter or not
             ok++;
             break;
             }
            }
          if (ok==0){
              result.add(k);//key is intersection
                }
           }
               
            
       return result; 
            
    }
     
     
     public static void print_display( ArrayList<Tokens> input){
         System.out.println("===========data==============");
        for(Tokens token :input)
                {
                   System.out.println(token.name);
                  ///System.out.println("jjjjj"+token.hmap.values()+"jjjj");
                    
                   for(String key:token.hmap.keySet()){
                      System.out.println(key+"  "+token.hmap.get(key)); 
                       System.out.println("-----------------------------");
                   
                   }
                     
                }

}
    
}
