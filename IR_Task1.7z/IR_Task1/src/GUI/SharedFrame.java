/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import BooleanModel.IncidenceMatrix;
import static invertedindexmodel.InvertedIndexModel.invertedModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import project_ir.doucument;

/**
 *
 * @author Amal Tarek
 */
public class SharedFrame extends JFrame implements ActionListener{
    
    public static JPanel H_panel;
    JMenuBar menubar;
    JMenu []menu;
    JMenuItem []about;
    JMenuItem []models;
    JMenuItem []file;
    Font f2;
    File[] files;
    JTextField File;
    public SharedFrame(){
        files = new File("src\\IR Documents\\").listFiles(); 
        Font f1 = new Font("Serfi",Font.ITALIC,15);
        f2 = new Font("Serfi",Font.BOLD+Font.ITALIC,15);
        menubar =new  JMenuBar();
        menu=new JMenu[3];
        menu[0] =new JMenu("  File  ");
        menu[1] = new JMenu("  IR Model  ");
        menu[2] =new JMenu("  About  ");
        
        menubar.add(menu[0]);
        menubar.add(menu[1]);
        menubar.add(menu[2]);
        
        file =new JMenuItem[2];
        file[0]=new JMenuItem("Browse Files...");
        file[1]=new JMenuItem("      Exit");
        
        for(int i=0;i<file.length;i++)
        {
            file[i].setFont(f1);
            menu[0].add(file[i]);
            if(i!=file.length-1)
                menu[0].addSeparator();
            file[i].addActionListener(this);
        }
        
        models =new JMenuItem[3];
        models[0]=new JMenuItem("   Boolean Model");
        models[1]=new JMenuItem("   Inverted Index");
        models[2]=new JMenuItem("   Positional Index");
        
        for(int i=0;i<models.length;i++)
        {
            models[i].setFont(f1);
            menu[1].add(models[i]);
            if(i!=models.length-1)
                menu[1].addSeparator();
            models[i].addActionListener(this);
        }
            
        for(int i=0;i<menu.length;i++)
        {
            menu[i].setForeground(Color.DARK_GRAY);
            menu[i].setFont(f2);  
        }
        
        about=new JMenuItem[1];
        about[0]=new JMenuItem("   About Us");
        about[0].addActionListener(this);
        about[0].setFont(f1);
        menu[2].add(about[0]);
        
        setLayout(new BorderLayout());
        this.setJMenuBar(menubar); 
        setSize(800,600);
        setTitle("Home");
        setLocationRelativeTo(null);
        setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setLayout(null);  
        this.setIconImage(new ImageIcon("logo.png").getImage()); 
        
       H_panel=new JPanel( null); 
       H_panel.setBounds(7,7,780,530); 
       H_panel.setBorder(new LineBorder(new Color(62,54,55),6));
       H_panel.setBackground(new Color(204,163,132));
        
        add(H_panel);
       
        
    }
   

    @Override
    public void actionPerformed(ActionEvent e) {
      if(e.getActionCommand()=="   About Us")
        {
            setVisible(false);
            dispose();
            new About().setVisible(true);
        }
        else if(e.getActionCommand()=="   Boolean Model")
        {
            this.setVisible(false);
            dispose();
            IncidenceMatrix IncMat = new IncidenceMatrix(files);
            new BM_IncMatrix(IncMat).setVisible(true);
        }
        else if(e.getActionCommand()=="   Inverted Index")// Inverted Index
        {
             setVisible(false);
             dispose();
             invertedModel(files);
             new InM_FilePostingList().setVisible(true);
        }
        else if(e.getActionCommand()=="   Positional Index")// Positional Index
        {
            setVisible(false);
            dispose();
            doucument.read_files(files);
            
            new PM_DocPosition().setVisible(true);
        }
        else if(e.getActionCommand()=="Browse Files...")// Browse Files
        {
            this.setVisible(false);
            dispose();
            new BM_Browse().setVisible(true);
        }
        else if(e.getActionCommand()=="      Exit")// show invoice for guest
        {
            this.setVisible(false);
            dispose();
        }else if(e.getActionCommand() == "Browse"){
             JFileChooser chooser = new JFileChooser();
            chooser.setMultiSelectionEnabled(true);
            FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
            chooser.setAcceptAllFileFilterUsed(false);
            chooser.setFileFilter(filter); 
            //chooser.addChoosableFileFilter(filter);
            int status = chooser.showOpenDialog(null);
            if (status == JFileChooser.APPROVE_OPTION) {
                 files = chooser.getSelectedFiles();
                 for(File file : files){
                     File.setText(file.getAbsolutePath()+" , ");
                 }     
                 File.repaint();
                 File.revalidate();

            } 
        }else if(e.getActionCommand() == " Boolean Model "){
            setVisible(false);
            dispose();
            IncidenceMatrix IncMat = new IncidenceMatrix(files);
            new BM_IncMatrix(IncMat).setVisible(true);
        }else if(e.getActionCommand() == "  Inverted Model  "){
             setVisible(false);
             dispose();
             invertedModel(files);
              new InM_FilePostingList().setVisible(true);
        }else if(e.getActionCommand() == "  Positional Model  "){
           setVisible(false);
            dispose();
            doucument.read_files(files);
            
            new PM_DocPosition().setVisible(true);
        }
       
       
    }
    
}
