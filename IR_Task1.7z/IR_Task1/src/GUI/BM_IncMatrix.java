/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import BooleanModel.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;

/**
 *
 * @author Amal Tarek
 */
public class BM_IncMatrix extends MainFrame{

    
    private IncidenceMatrix IncMat;
   
    
    public BM_IncMatrix(IncidenceMatrix IncMat){
        this.IncMat = IncMat;
        this.setTitle("Boolean Model");
        
       Title.setText("  Welcome In Boolean Retrieval Model ");
       
       t1.setTitle("Query Command");
       
       Query.setText("  Please, Enter Your Query  ...");
       
        Query.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(Query.getText().equals("  Please, Enter Your Query  ..."))
            {
                Query.setCaretPosition(1);
                Query.setFocusable(true);
                Query.requestFocus();
                Query.setText(" ");
                Query.repaint();
                Query.revalidate();
                
            }}
        });
        
        go.setText("Search");
       
        t2.setTitle("Incidence Matrix");
        
        table = displayInsienceMatrix(IncMat);
        
         table.setFont(f2);
       // table.setShowHorizontalLines(true);
       // table.setShowVerticalLines(false);
       //table.setEnabled(false);
        table.setDefaultEditor(Object.class, null);
         JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(40, 40));
        th.setFont(f2);
        th.setBackground(new Color(30,25,53));
        th.setForeground(Color.WHITE);  
        
         table.setRowHeight(50);
        //table.getColumnModel().setColumnMargin(130);
        
        //table.setAlignmentY(TOP_ALIGNMENT);
       // table.setBorder(new LineBorder(new Color(62,54,55),6));
         
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        centerRenderer.setBackground(new Color(30,25,53));
        centerRenderer.setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
        DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
        centerRenderer2.setHorizontalAlignment( JLabel.CENTER );
        for(int i=1; i <table.getColumnCount() ; i++)
            table.getColumnModel().getColumn(i).setCellRenderer( centerRenderer2 );
        
         JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(15, 30, 700, 290);
        scrollPane.setBackground(new Color(204,163,132));
        scrollPane.getVerticalScrollBar().setForeground(Color.red);
       
        
       scrollPane.setViewportView(table);
       //table.setTableHeader(null);
       
        P_IncMatrix.add(scrollPane, BorderLayout.CENTER);
        //table = StyleTable(table);
    }
    
     
      public JTable displayInsienceMatrix(IncidenceMatrix IncMat){     
        ArrayList<Document> lstDocs = IncMat.getFile().getLstDocs();
        Object Docs[] = new Object[lstDocs.size()+1];
        Object terms[][] = new Object[IncMat.getIncMat().size()][lstDocs.size()+1];
        Docs[0]="";
        for(int i=0; i < lstDocs.size() ; i++){
            Docs[i+1] = lstDocs.get(i).getDocName();
        } int j =0;
        for (String Term : IncMat.getIncMat().keySet()) {
            String[] bainryVector = IncMat.getIncMat().get(Term).split("");
            terms[j][0] = Term;
            for(int i =0; i < lstDocs.size() ; i++)
                terms[j][i+1] = bainryVector[i];
            j++;
        } 
        JTable table = new JTable(terms, Docs);
        
        return table;
    }
      
      
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == go){
            String query = Query.getText().replaceAll("[^a-zA-Z() ]", " ").replaceAll("\\s+", " ").trim();
            if(query.isEmpty() || query.equals(" ") || Query.getText().equals("  Please, Enter Your Query  ...")){
                // Message JOption Pane ("Please , Enter Your Query")
                JOptionPane.showMessageDialog(this, "Please, Enter a Your Query", "Error", JOptionPane.ERROR_MESSAGE);
                setVisible(false);
                dispose();
                new BM_IncMatrix(IncMat).setVisible(true);
            }
            else{
                QueryChecker queryCheck = new QueryChecker(query);
                if(!queryCheck.ValidRoundBrackets() || !queryCheck.ValidQuery()){
                        //System.out.println("Please, Enter a Valid Query");
                        JOptionPane.showMessageDialog(this, "Please, Enter a Valid Query", "Error", JOptionPane.ERROR_MESSAGE);
                        setVisible(false);
                        dispose();
                        new BM_IncMatrix(IncMat).setVisible(true);
                 }else{
                            BooleanModel bm = new BooleanModel(IncMat,queryCheck,queryCheck.getQuery());
                            String Result="";
                            if(queryCheck.getQuery().split(" ").length != 1){
                                Result = bm.ExecuteQuery(0, "");
                            }else{
                                Result = bm.getBinaryVector(queryCheck.getQuery().trim());
                            }
                        
                          bm.setResult(Result);
                         if(!queryCheck.CheckError() || !queryCheck.CheckResult(Result,IncMat)){
                            JOptionPane.showMessageDialog(this, "No Search Result Found", "Error", JOptionPane.ERROR_MESSAGE);
                               // System.out.println("No Search Result Found");
                            setVisible(false);
                            dispose();
                            new BM_IncMatrix(IncMat).setVisible(true);
                        }else{
                             setVisible(false);
                             dispose();
                             new BM_Result(bm).setVisible(true);
                         }
                         
                   }
                }
                
                
        }
    }
}
