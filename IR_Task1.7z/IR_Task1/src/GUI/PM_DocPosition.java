/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.SharedFrame.H_panel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import project_ir.PositionalIndex;
import project_ir.Tokens;
import project_ir.doucument;

/**
 *
 * @author esraa
 */
public class PM_DocPosition extends MainFrame{
    
   ArrayList<Tokens> alltokens;
    
    public PM_DocPosition(){
        this.setTitle("Positional Model");
        
       Title.setText("  Welcome In Positional Index Model ");
       
       t1.setTitle("Query Command");
       
       Query.setText("  Please, Enter Your Query  ...");
       
        Query.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(Query.getText().equals("  Please, Enter Your Query  ..."))
            {
                Query.setCaretPosition(1);
                Query.setFocusable(true);
                Query.requestFocus();
                Query.setText(" ");
                Query.repaint();
                Query.revalidate();
                
            }}
        });
        
        go.setText("Search");
        
        t2.setTitle("Documents Positions");
        
        table = displayInsienceMatrix();
        
         table.setFont(f2);
       // table.setShowHorizontalLines(true);
       // table.setShowVerticalLines(false);
       //table.setEnabled(false);
        table.setDefaultEditor(Object.class, null);
         JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(40, 40));
        th.setFont(f2);
        th.setBackground(new Color(30,25,53));
        th.setForeground(Color.WHITE);  
        
         table.setRowHeight(50);
        //table.getColumnModel().setColumnMargin(130);
        
        //table.setAlignmentY(TOP_ALIGNMENT);
       // table.setBorder(new LineBorder(new Color(62,54,55),6));
         
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        centerRenderer.setBackground(new Color(30,25,53));
        centerRenderer.setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
        DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
        centerRenderer2.setHorizontalAlignment( JLabel.CENTER );
        for(int i=1; i <table.getColumnCount() ; i++)
            table.getColumnModel().getColumn(i).setCellRenderer( centerRenderer2 );
        
         JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(15, 30, 700, 290);
        scrollPane.setBackground(new Color(204,163,132));
        scrollPane.getVerticalScrollBar().setForeground(Color.red);
       
        
       scrollPane.setViewportView(table);
       //table.setTableHeader(null);
       
        P_IncMatrix.add(scrollPane, BorderLayout.CENTER);
        //table = StyleTable(table);
    }
    
     
      public JTable displayInsienceMatrix(){     
      alltokens=PositionalIndex.Positional_index(doucument.data);
      int i=0;
      for (Tokens token: alltokens) {
            //terms[j][0] = token.name;
            
           for(String key:token.hmap.keySet()){
               
                 i++;
                }
                     
          
        } 
        Object Docs[] = new Object[]{"Term" , "Doc Name","positions"};
        Object terms[][] = new Object[i][3];
         int j =0;
        for (Tokens token: alltokens) {
            //terms[j][0] = token.name;
            
           for(String key:token.hmap.keySet()){
               terms[j][0] = token.name;
               terms[j][1] = key;
               terms[j][2] = token.hmap.get(key);
                 j++;
                }
                     
          
        } 
        JTable table = new JTable(terms, Docs);
        
        return table;
        
        
       

        
    }
      
       public void actionPerformed(ActionEvent e) {
        if(e.getSource() == go){
            if(Query.getText().isEmpty() || Query.getText().equals(" ") || Query.getText().equals("  Please, Enter Your Query  ...")){
                // Message JOption Pane ("Please , Enter Your Query")
                JOptionPane.showMessageDialog(this, "Please, Enter a Your Query", "Error", JOptionPane.ERROR_MESSAGE);
                setVisible(false);
                dispose();
                new PM_DocPosition().setVisible(true);
            }
            else {
             ArrayList<Tokens> input= PositionalIndex.display_postional_index(Query.getText(),alltokens);
             ArrayList<String> r=PositionalIndex.match_query(input);
             PM_Result result =new PM_Result(input,r);
             setVisible(false);
             dispose();
             result.setVisible(true);
            
            }
            
            
        }} 
}
