/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import BooleanModel.IncidenceMatrix;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Amal Tarek
 */
public class BM_Browse extends SharedFrame{
    
    JLabel Title,Img;
    JButton browseBtn,boolBtn,InvertedBtn,PositionalBtn;
   JPanel P_Img,P_File;
   TitledBorder t;
   
    public BM_Browse(){
         Font TitleFont = new Font("Monotype Corsiva",Font.BOLD+Font.ITALIC,36);
         Font fBtn = new Font("Serfi",Font.BOLD+Font.ITALIC,20);
         this.setTitle("Home");
         Title =new  JLabel("  Welcome In IR System ^_^");
         Title.setBounds(190,20, 450, 30);
         Title.setFont(TitleFont);
         Title.setForeground(Color.black);
         H_panel.add(Title);
         P_Img=new JPanel(null);
        P_Img.setBounds(20, 30, 717, 300);
        Img =new JLabel(new ImageIcon("CM.png"));
        Img.setBounds(20,30, 717, 300);
        P_Img.setBackground( new Color(204,163,132) );
        //P_Img.setBorder(new LineBorder(new Color(175, 145, 74),5));
        P_Img.add(Img);
       
        
        
        P_File = new JPanel(null);
        t = new TitledBorder("Browse Files");
        t.setTitleColor(Color.BLACK);
        P_File.setBackground(new Color(204,163,132));
        P_File.setBorder(t);
        P_File.setBounds(20,345, 740,90);
        
        File=new JTextField("  Please, Click Browse To Browse your Files ...");
        File.setCaretPosition(1);
        File.setFocusable(false);
        File.setBounds(15,25,570, 50);
        File.setFont(f2);
        File.setBorder(new LineBorder(Color.black,5));
        File.setBackground(Color.lightGray);
        
        
        browseBtn=new JButton ("Browse");
     
        browseBtn.addActionListener(this);
        browseBtn.setFocusPainted(false);
        browseBtn.setFont(f2);
        browseBtn.setBounds(600, 25, 120, 50);
        browseBtn.setBorder(new LineBorder(Color.BLACK,2));
        
        P_File.add(File);
        P_File.add(browseBtn); 
        
        boolBtn=new JButton (" Boolean Model ");
     
        boolBtn.addActionListener(this);
        boolBtn.setFocusPainted(false);
        boolBtn.setFont(fBtn);
        boolBtn.setBounds(50, 450, 200,60);
        boolBtn.setBorder(new LineBorder(Color.BLACK,2));
        
        
        InvertedBtn=new JButton ("  Inverted Model  ");
     
        InvertedBtn.addActionListener(this);
        InvertedBtn.setFocusPainted(false);
        InvertedBtn.setFont(fBtn);
        InvertedBtn.setBounds(280, 450, 200,60);
        InvertedBtn.setBorder(new LineBorder(Color.BLACK,2));
        
        PositionalBtn=new JButton ("  Positional Model  ");
     ///
        PositionalBtn.addActionListener(this);
        PositionalBtn.setFocusPainted(false);
        PositionalBtn.setFont(fBtn);
        PositionalBtn.setBounds(500, 450, 200,60);
        PositionalBtn.setBorder(new LineBorder(Color.BLACK,2));
        
        
        
        H_panel.add(P_Img); 
        H_panel.add(P_File);
        H_panel.add(boolBtn);
        H_panel.add(InvertedBtn);
        H_panel.add(PositionalBtn);
    }
    
      public static void main(String[] args) {
            new BM_Browse().setVisible(true);

    } 
      
}
