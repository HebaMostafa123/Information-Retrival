/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import project_ir.Tokens;

/**
 *
 * @author esraa
 */
public class PM_Result extends MainFrame{
    
   ArrayList<Tokens> alltokens;
   ArrayList<String> r;
    
    public PM_Result(ArrayList<Tokens>alltokens,ArrayList<String> r){
        this.setTitle("Positional Model");
        this.alltokens=alltokens;
       this.r=r;
        
       Title.setText("  Welcome In Positional Index Model ");
       
       t1.setTitle("Matched Documents");
       
       
       if(r.size()==0){
           Query.setText(" There's No Matched documents");
       }else{
           Query.setText(r.toString());
       }
            
       
        Query.setBounds(15,25,710, 50);
        
        P_Query.remove(go);
        
        t2.setTitle("Postional Index");
        
        table = displayInsienceMatrix();
        
         table.setFont(f2);
       // table.setShowHorizontalLines(true);
       // table.setShowVerticalLines(false);
       //table.setEnabled(false);
        table.setDefaultEditor(Object.class, null);
         JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(40, 40));
        th.setFont(f2);
        th.setBackground(new Color(30,25,53));
        th.setForeground(Color.WHITE);  
        
         table.setRowHeight(50);
        //table.getColumnModel().setColumnMargin(130);
        
        //table.setAlignmentY(TOP_ALIGNMENT);
       // table.setBorder(new LineBorder(new Color(62,54,55),6));
         
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        centerRenderer.setBackground(new Color(30,25,53));
        centerRenderer.setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
        DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
        centerRenderer2.setHorizontalAlignment( JLabel.CENTER );
        for(int i=1; i <table.getColumnCount() ; i++)
            table.getColumnModel().getColumn(i).setCellRenderer( centerRenderer2 );
        
         JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(15, 30, 700, 290);
        scrollPane.setBackground(new Color(204,163,132));
        scrollPane.getVerticalScrollBar().setForeground(Color.red);
       
        
       scrollPane.setViewportView(table);
       //table.setTableHeader(null);
       
        P_IncMatrix.add(scrollPane, BorderLayout.CENTER);
        //table = StyleTable(table);
    }
    
     
      public JTable displayInsienceMatrix(){     
      
      int i=0;
      for (Tokens token: alltokens) {
            //terms[j][0] = token.name;
            
           for(String key:token.hmap.keySet()){
               
                 i++;
                }
                     
          
        } 
        Object Docs[] = new Object[]{"Term" , "Doc Name","positions"};
        Object terms[][] = new Object[i][3];
         int j =0;
        for (Tokens token: alltokens) {
            //terms[j][0] = token.name;
            
           for(String key:token.hmap.keySet()){
               terms[j][0] = token.name;
               terms[j][1] = key;
               terms[j][2] = token.hmap.get(key);
                 j++;
                }
                     
          
        } 
        JTable table = new JTable(terms, Docs);
        
        return table;
        
        
       

      }
    }