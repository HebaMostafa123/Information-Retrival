/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import BooleanModel.BooleanModel;
import BooleanModel.Document;
import BooleanModel.IncidenceMatrix;
import static BooleanModel.Main.displayBainryVectors;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 *
 * @author Amal Tarek
 */
public class BM_Result extends MainFrame{
    
    private BooleanModel BoolModel;
    public BM_Result(BooleanModel BooMode){
        this.BoolModel = BooMode;
        this.setTitle("Boolean Model Result");
        
       Title.setText("  Result of Boolean Model  = " + BoolModel.getResult());
       Title.setBounds(200,20, 400, 30);
       t1.setTitle("Matched Documents");
       
       if(BoolModel.getMatchedDocuments(BoolModel.getResult()).length()!=0)
            Query.setText(" Matched Documents : "+ BoolModel.getMatchedDocuments(BoolModel.getResult()));
        else
            Query.setText(" There's No matched Document");          
        
        Query.setBounds(15,25,710, 50);
        
        P_Query.remove(go);
        t2.setTitle("Binary Vectors");
        
        table = displayBainryVectors(BoolModel.getTermsBainryVector());
        
         table.setFont(f2);
       // table.setShowHorizontalLines(true);
       // table.setShowVerticalLines(false);
       //table.setEnabled(false);
        table.setDefaultEditor(Object.class, null);
         JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(40, 40));
        th.setFont(f2);
        th.setBackground(new Color(30,25,53));
        th.setForeground(Color.WHITE);  
        
         table.setRowHeight(50);
        //table.getColumnModel().setColumnMargin(130);
        
        //table.setAlignmentY(TOP_ALIGNMENT);
       // table.setBorder(new LineBorder(new Color(62,54,55),6));
         
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        centerRenderer.setBackground(new Color(30,25,53));
        centerRenderer.setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
        DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
        centerRenderer2.setHorizontalAlignment( JLabel.CENTER );
        for(int i=1; i <table.getColumnCount() ; i++)
            table.getColumnModel().getColumn(i).setCellRenderer( centerRenderer2 );
        
         JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(15, 30, 700, 290);
        scrollPane.setBackground(new Color(204,163,132));
        scrollPane.getVerticalScrollBar().setForeground(Color.red);
       
        
       scrollPane.setViewportView(table);
       //table.setTableHeader(null);
       
        P_IncMatrix.add(scrollPane, BorderLayout.CENTER);
        //table = StyleTable(table);
    }
    
    
     public JTable displayBainryVectors(ArrayList<String> QueryTerms){  
        Object Docs[] = new Object[BoolModel.getDocsSize()+1];
        Object terms[][] = new Object[QueryTerms.size()][BoolModel.getDocsSize()+1];
        Docs[0]="";
        for(int i=0; i < BoolModel.getDocsSize() ; i++){
            Docs[i+1] = BoolModel.getIncMat().getFile().getLstDocs().get(i).getDocName();
        }
        int j =0;
        String[] BinaryVector,parts;
        for(String term : QueryTerms){
            parts = term.split(" ");
            terms[j][0] = parts[0];
            BinaryVector = parts[1].split("");
            for(int i =0; i < BinaryVector.length ; i++)
                terms[j][i+1] = BinaryVector[i];
            j++;
        }
        JTable table = new JTable(terms, Docs);
        
        return table;
    }
}
