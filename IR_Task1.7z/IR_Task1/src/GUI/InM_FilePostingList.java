/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.SharedFrame.H_panel;
import static invertedindexmodel.InvertedIndexModel.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 *
 * @author Amal Tarek
 */
public class InM_FilePostingList extends MainFrame{
    
   
    
    public InM_FilePostingList(){
       this.setTitle("Inverted Index");
        
       Title.setText(" Welcome In Inverted Index Model ");
       
       t1.setTitle("Query Command");
       
       Query.setText("  Please, Enter Your Query  ...");
       
        Query.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(Query.getText().equals("  Please, Enter Your Query  ..."))
            {
                Query.setCaretPosition(1);
                Query.setFocusable(true);
                Query.requestFocus();
                Query.setText(" ");
                Query.repaint();
                Query.revalidate();
                
            }}
        });
        
        go.setText("Search");
        
        t2.setTitle("File Posting List");
        
        table = displayInsienceMatrix();
        
         table.setFont(f2);
       // table.setShowHorizontalLines(true);
       // table.setShowVerticalLines(false);
       //table.setEnabled(false);
        table.setDefaultEditor(Object.class, null);
         JTableHeader th = table.getTableHeader();
        th.setPreferredSize(new Dimension(40, 40));
        th.setFont(f2);
        th.setBackground(new Color(30,25,53));
        th.setForeground(Color.WHITE);  
        
         table.setRowHeight(50);
        //table.getColumnModel().setColumnMargin(130);
        
        //table.setAlignmentY(TOP_ALIGNMENT);
       // table.setBorder(new LineBorder(new Color(62,54,55),6));
         
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        centerRenderer.setBackground(new Color(30,25,53));
        centerRenderer.setForeground(Color.WHITE);
        table.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
        DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
        centerRenderer2.setHorizontalAlignment( JLabel.CENTER );
        for(int i=1; i <table.getColumnCount() ; i++)
            table.getColumnModel().getColumn(i).setCellRenderer( centerRenderer2 );
        
         JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(15, 30, 700, 290);
        scrollPane.setBackground(new Color(204,163,132));
        scrollPane.getVerticalScrollBar().setForeground(Color.red);
       
        
       scrollPane.setViewportView(table);
       //table.setTableHeader(null);
       
        P_IncMatrix.add(scrollPane, BorderLayout.CENTER);
        //table = StyleTable(table);
    }
    
     
      public JTable displayInsienceMatrix(){     
        //ArrayList<Document> lstDocs = IncMat.getFile().getLstDocs();
        Object Docs[] = new Object[4];
        Object terms[][] = new Object[TokenWithFreqDocList.size()][5];
        //Docs[0]="";
        for (int i =0;i<4 ; i++){
            Docs[i]="";
        }
        int j =0;
        for (int k=0;k <TokenWithFreqDocList.size();k++) {
            terms[k][0] = TokenWithFreqDocList.get(k).getName();
            for(int i =0; i < TokenWithFreqDocList.get(k).DocsName.size(); i++){
                terms[k][i+1] = TokenWithFreqDocList.get(k).DocsName.get(i);
                System.out.println(terms[k][i+1]);}
            j++;
        } 
        JTable table = new JTable(terms, Docs);
        return table;
    }
      public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == go){
          if(Query.getText().isEmpty() || Query.getText().equals(" ") || Query.getText().equals("  Please, Enter Your Query  ...")){
                // Message JOption Pane ("Please , Enter Your Query")
                JOptionPane.showMessageDialog(this, "Please, Enter a Your Query", "Error", JOptionPane.ERROR_MESSAGE);
                setVisible(false);
                dispose();
                new InM_FilePostingList().setVisible(true);
            }
        else{
        if(!ISValidQuery(Query.getText().replaceAll("[^a-zA-Z()\\s+]", " ")))
        {
            JOptionPane.showMessageDialog(this, "Please, Enter a Valid Query", "Error", JOptionPane.ERROR_MESSAGE);
            setVisible(false);
            dispose();
            new InM_FilePostingList().setVisible(true);

        }
        else
        {
           QueryPostingList(Query.getText(),TokenWithFreqDocList);  
           String Result = ExecuteQuery(0,"");
           Result = Result.replaceAll("[@]", " ");
           setVisible(false);
           dispose();
           new InM_Result(Result).setVisible(true);
        }
        }
        }
      }
}

