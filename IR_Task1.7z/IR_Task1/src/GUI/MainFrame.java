/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 *
 * @author Amal Tarek
 */
public class MainFrame extends SharedFrame{
    JLabel Title;
    JPanel P_Query,P_IncMatrix;
    TitledBorder t1,t2;
    JTextField Query;
    JButton go;
    JTable table;
    
    public MainFrame()
        {
        Font TitleFont = new Font("Monotype Corsiva",Font.BOLD+Font.ITALIC,26);
  
         Title =new  JLabel();
         Title.setBounds(190,20, 400, 30);
         Title.setFont(TitleFont);
         Title.setForeground(Color.black);
        
         
        P_Query = new JPanel(null);
        t1 = new TitledBorder("");
        t1.setTitleColor(Color.BLACK);
        P_Query.setBackground(new Color(204,163,132));
        P_Query.setBorder(t1);
        P_Query.setBounds(20,70, 740,90);
        
        Query=new JTextField("");
        
        Query.setFocusable(false);
       
        Query.setBounds(15,25,570, 50);
        Query.setFont(f2);
        Query.setBorder(new LineBorder(Color.black,5));
        Query.setBackground(Color.lightGray);
        
        
        go=new JButton ("");
     
        go.addActionListener(this);
        go.setFocusPainted(false);
        go.setFont(f2);
        go.setBounds(600, 25, 120, 50);
        go.setBorder(new LineBorder(Color.BLACK,2));
        
        P_Query.add(Query);
        P_Query.add(go); 
        
        P_IncMatrix = new JPanel(null);
        t2 = new TitledBorder("");
        t2.setTitleColor(Color.BLACK);
        P_IncMatrix.setBackground(new Color(204,163,132));
        P_IncMatrix.setBorder(t2);
        P_IncMatrix.setBounds(20,170, 740,340);
        
        
      
        
        H_panel.add(Title);
        H_panel.add(P_Query);
        H_panel.add(P_IncMatrix);
            
    }

}
