/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invertedindexmodel;
import java.io.*;
import static java.lang.System.exit;
import static java.rmi.Naming.list;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InvertedIndexModel {
    private static String readFile(String fileName)
    {
        String Text = null;
        String content = "";
        try {      
            content = new Scanner(new File(fileName)).useDelimiter("\\Z").next();
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
       return content;
    }
    
    private static ArrayList<String> FileTokinization(String Text)
    {
        ArrayList<String> words = new ArrayList<String>();
        Scanner scanner = null;
        Pattern pattern=Pattern.compile("[^a-zA-Z]");
        String word;

        scanner = new Scanner(Text);
        while(scanner.hasNext()){
            scanner.useDelimiter(pattern);
            word=(scanner.next().toLowerCase());
        if(!word.equals("") && !word.equals("and") && !word.equals("or") && !word.equals("not")){
            words.add(word);
            }
         }
        return(words);
    }
    
    private static ArrayList<Tokenes> makeObj(ArrayList<String> tokens,String docName,int docId)
    {
        ArrayList<Tokenes> objs = new ArrayList<Tokenes>();
        for(int i=0;i<tokens.size();i++)
        {
         Tokenes Token = new Tokenes();
         Token.Name = tokens.get(i);
         Token.Doc_id = docId;
         Token.Doc_name = docName;
         objs.add(Token);
        }
        
        return(objs);
    }
     
    private static void appendToken(ArrayList<Tokenes>Tokens,ArrayList<Tokenes>AllTokens)
    {
        for (int i=0;i<Tokens.size();i++)
        {
         AllTokens.add(Tokens.get(i));
        }
    }
     
    private static boolean IsEqualDoc(Tokenes obj1,Tokenes obj2)
    {
        return (obj1.getName().equals(obj2.getName()))&&(obj1.Doc_id == obj2.Doc_id);
    }
       
    private static ArrayList<Tokenes> uniqueDoc(ArrayList<Tokenes> Tokens)
    {
        ArrayList <Tokenes> New = new ArrayList<Tokenes>(); 
        New.add(Tokens.get(0));
        for (int i = 0;i<Tokens.size();i++)
        {
          int count=0;
          for(int j=0;j<New.size();j++)
          {
              if(IsEqualDoc(New.get(j),Tokens.get(i)))
              {
                  count = 1;
                  break;
              }
          }
          if(count==0)
          {
             New.add(Tokens.get(i));
          }
        }
        return (New);
    }
    private static ArrayList<Tokenes> calcFrequency(ArrayList <Tokenes> Tokens)
    {
        ArrayList <Tokenes> New = new ArrayList<Tokenes>(); 
        for (int i = 0;i<Tokens.size();i++)
        {
          Tokenes Temp = new Tokenes();
          int count=0;
          for(int j=0;j<Tokens.size();j++)
          {
              if(Tokens.get(i).getName().equals(Tokens.get(j).getName()))
              {
                  Temp.DocsId.add(Tokens.get(j).Doc_id);
                  Temp.DocsName.add(Tokens.get(j).Doc_name);
                  count++;
              }
          }
          if(count == 0)
          {
              Temp.DocsId.add(Tokens.get(i).Doc_id);
              Temp.DocsName.add(Tokens.get(i).Doc_name);
              count = 1;
          }
          Temp.Name = Tokens.get(i).Name;
          Temp.Frequency = count;
          New.add(Temp);
        }
        return (New);
    }
    
    public static ArrayList <Tokenes> TokenWithFreqDocList = new ArrayList<Tokenes>();
    private static ArrayList <String >filesNames = new ArrayList <String>();

    public static ArrayList<Tokenes> invertedModel(File[] files)
    {
        for(File file : files){
            filesNames.add(file.getName());
        }
        
     /*   filesNames.add(fileName2);
        filesNames.add(fileName3);
        filesNames.add(fileName4);*/

        String Text1,Text2,Text3,Text4;
        ArrayList <Tokenes> AllTokens = new ArrayList<Tokenes>();
        ArrayList <Tokenes> AllUniqueDocTokens = new ArrayList<Tokenes>();
        System.out.println(filesNames.size());
        for (int i=0;i< filesNames.size();i++){
            Text1 = readFile(files[i].getAbsolutePath());
            appendToken(makeObj(FileTokinization(Text1),filesNames.get(i),i),AllTokens);
        }
        //All tokens in AllTokens Array Without sorting
        /*Text1 = readFile(fileName1);
        appendToken(makeObj(FileTokinization(Text1),fileName1,1),AllTokens);
        Text2 = readFile(fileName2);
        appendToken(makeObj(FileTokinization(Text2),fileName2,2),AllTokens);
        Text3 = readFile(fileName3);
        appendToken(makeObj(FileTokinization(Text3),fileName3,3),AllTokens);
        Text4 = readFile(fileName4);
        appendToken(makeObj(FileTokinization(Text4),fileName4,4),AllTokens);*/
        
        for (int i=0;i<AllTokens.size();i++)
        {
            System.out.print(AllTokens.get(i).Name +" : ");
            System.out.print(AllTokens.get(i).Doc_name+" : ");
            System.out.print(AllTokens.get(i).Doc_id);
            System.out.println();
        }
            System.out.println("----------------------");
        //All Tokens in AllTokens array sorting
        Collections.sort(AllTokens, new Comparator<Tokenes>() {
        @Override
        public int compare(Tokenes lhs, Tokenes rhs) {
          return lhs.getName().compareTo(rhs.getName());
        }
        });
        
        for (int i=0;i<AllTokens.size();i++)
        {
            System.out.print(AllTokens.get(i).Name +" : ");
            System.out.print(AllTokens.get(i).Doc_name+" : ");
            System.out.print(AllTokens.get(i).Doc_id);
            System.out.println();
        }
            System.out.println("----------------------");

      
        //Make Document Unique 
        AllUniqueDocTokens = uniqueDoc(AllTokens);
        
        //Make Tokens Unique
        TokenWithFreqDocList = uniqueTokens(calcFrequency(AllUniqueDocTokens));
        
         for (int i=0;i<TokenWithFreqDocList.size();i++)
        {
            System.out.print(TokenWithFreqDocList.get(i).Name +" : ");
            System.out.print(TokenWithFreqDocList.get(i).DocsId+" : ");
            System.out.print(TokenWithFreqDocList.get(i).DocsName);
            System.out.println();
        }
            System.out.println("--------------------");       
        return(TokenWithFreqDocList);
    }      
    private static ArrayList<String> QueryTokinization(String Text)
    {
        ArrayList<String> words = new ArrayList<String>();
        Scanner scanner = null;
        Pattern pattern=Pattern.compile("[^a-zA-Z]");
        String word;

        scanner = new Scanner(Text);
        while(scanner.hasNext()){
            scanner.useDelimiter(pattern);
            word=(scanner.next().toLowerCase());
        if(!word.equals("")){
            words.add(word);
            }
         }
        return(words);
    }
    public static String [] QueryTerms;
    public static ArrayList<Tokenes> QueryTokenList = new ArrayList<Tokenes>();

    public static void QueryPostingList(String Text,ArrayList <Tokenes> Tokens)
    {
          QueryTerms = Text.toLowerCase().split("");
          ArrayList<String> queryTokens = new ArrayList<String>();
          queryTokens = QueryTokinization(Text);
          Set<String> hs = new HashSet<>();
          hs.addAll(queryTokens);
          queryTokens.clear();
          queryTokens.addAll(hs);
          
          Collections.sort(queryTokens);
          int count = 0;
          for(int  i=0;i<queryTokens.size();i++)
          {
              for(int j = 0;j<Tokens.size();j++)
              {
                  if(queryTokens.get(i).equals(Tokens.get(j).getName()))
                  {
                      QueryTokenList.add(Tokens.get(j));
                      count++;
                  }
              }
          }
          
           for (int i=0;i<QueryTokenList.size();i++)
        {
            System.out.print(QueryTokenList.get(i).Name +" : ");
            System.out.print(QueryTokenList.get(i).DocsId+" : ");
            System.out.print(QueryTokenList.get(i).DocsName);
            System.out.println();
        }
            System.out.println("--------------------");

          
         /* Collection<Integer> similarDocId = new HashSet<Integer>(MatchTokens.get(0).DocsId);
          Collection<String> similarDocName = new HashSet<String>(MatchTokens.get(0).DocsName);

          
          for(int i =1;i< MatchTokens.size();i++)
          {
             similarDocId.retainAll(MatchTokens.get(i).DocsId);
             similarDocName.retainAll(MatchTokens.get(i).DocsName);

          }
          if(similarDocId.size() != 0){ 
          System.out.println("Matched In : "+ similarDocId);
          System.out.println("Matched In : "+similarDocName);}
          else
          {
              System.out.println("Not Matched");
          }*/

    } 
    private static boolean IsEqualToken(Tokenes obj1,Tokenes obj2)
    {
        return (obj1.getName().equals(obj2.getName()));
    }
    private static ArrayList<Tokenes> uniqueTokens(ArrayList<Tokenes> Tokens)
    {
        ArrayList <Tokenes> New = new ArrayList<Tokenes>(); 
        New.add(Tokens.get(0));
        for (int i = 0;i<Tokens.size();i++)
        {
          int count=0;
          for(int j=0;j<New.size();j++)
          {
              if(IsEqualToken(New.get(j),Tokens.get(i)))
              {
                  count = 1;
                  break;
              }
          }
          if(count==0)
          {
             New.add(Tokens.get(i));
          }
        }
        return (New);
    }
    public static int prantetthes;
    public static boolean ISValidQuery(String word)
    {
        String [] words;
        words = word.split("");

        ArrayList<Integer> op =  new ArrayList<Integer>();
        ArrayList<Integer> close =  new ArrayList<Integer>();

        for(int i=0;i< words.length;i++)
        {
            if(words[i].equals("("))
            {
                op.add(i);
            }
            else if(words[i].equals(")"))
            {
                close.add(i);
            }
        }
        if(op.size() != close.size())
        {
            return false;
        }
        for(int i = 0;i<close.size();i++)
        {
            if(op.contains(close.get(i)-1))
            {
                return false;
            }
        }
        prantetthes = op.size();
        return true;            
    }    
    private static int counter = -1 ;
    private static String[] TmpExpr = new String[20];
     
    public static String ExecuteQuery(int i, String expr){
       if(i == QueryTerms.length){
           if(expr != "") 
                return ExecuteExpr(expr);
       }
       else if(QueryTerms[i].equals(")") ){
           expr = ExecuteExpr(expr) + " ";
           if(TmpExpr[counter]!= null)
               expr = TmpExpr[counter] + expr ;               
           counter--;

       }else if(QueryTerms[i].equals("(")){
            counter++;
            if(expr != ""){// Nested Parenthesis store last parent hesis in variable
                TmpExpr[counter] = expr + " ";
                expr = ""; 
            }
       }else {
           expr += QueryTerms[i];
       }
       return ExecuteQuery(++i,expr);
    }
    public static String ExecuteExpr(String expr){
        ArrayList<String> lst_terms= new ArrayList<String>(Arrays.asList(expr.split(" ")));
        removeAdditionalSpaces(lst_terms);
        for (int i = 0; i < lst_terms.size(); i++) {
            String nextTerm=new String();
                if(lst_terms.get(i).equalsIgnoreCase("NOT")){
                lst_terms.remove(i);
                if(i != lst_terms.size()){
                nextTerm = lst_terms.get(i).trim();
                expr = ProcessNotOp(nextTerm);}
                else{
                   lst_terms.add("");
                   expr = ProcessNotOp("");
                }
                lst_terms.set(i, expr);  
            }
        }
        for (int j = 0; j < lst_terms.size(); j++) {
             if(lst_terms.get(j).equalsIgnoreCase("AND")){
                lst_terms.remove(j);
                String prevTerm = new String();
                if(j!=0){
                prevTerm = lst_terms.get(--j).trim();
                }
                else
                {
                prevTerm ="";
                }
                lst_terms.remove(j);
                if(j != lst_terms.size()){
                String nextTerm = lst_terms.get(j).trim();
                expr = ProcessAndOp(prevTerm,nextTerm);}
                else{
                   lst_terms.add("");
                   expr = ProcessAndOp(prevTerm,"");
                }
                lst_terms.set(j, expr); 
            } 
        }
        for (int k = 0; k < lst_terms.size(); k++) {
             if(lst_terms.get(k).equalsIgnoreCase("OR")){
                lst_terms.remove(k);
                String prevTerm = new String();
                String nextTerm = new String();
                if(k!=0){
                prevTerm = lst_terms.get(--k).trim();
                }
                else
                {
                prevTerm ="";
                }
                lst_terms.remove(k);
                 if(k != lst_terms.size()){
                 nextTerm = lst_terms.get(k).trim();
                expr = ProcessOrOp(prevTerm,nextTerm);}
                else{
                   lst_terms.add("");
                   expr = ProcessOrOp(prevTerm,"");
                }
                lst_terms.set(k, expr);  
            } 
        }   
       return String.join("", lst_terms); 
    }
    public static String ProcessNotOp(String term){
         ArrayList <String> nextMatch = new ArrayList<String>();
         ArrayList <String> Match = new ArrayList<String>();
         ArrayList <String> Result = new ArrayList<String>(filesNames);
         String output = new String();
      
         if(term.equals(""))
         {
                for (String s : Result)
            {
                output +="@"+s+"@";
            }
                return output;    
         }
         else if(!term.contains(".txt"))
         {
                for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
             if(term.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   Match.addAll(TokenWithFreqDocList.get(j).DocsName);
               }
         }
        Result.removeAll(Match);
            for (String s : Result)
            {
                output +="@"+s+"@";
            }
                return output;    
         }
         else if(term.contains(".txt"))
         {
             for (String s : Result)
            {
                if(!term.contains(s))
                {
                   output +="@"+s+"@";
                }
            }
             return output;    
         }
         
        return output;    
    }
    public static String ProcessAndOp(String prevTerm,String nextTerm){
        ArrayList <String> prevMatch = new ArrayList<String>();
        ArrayList <String> nextMatch = new ArrayList<String>();
        String output = new String();
       
        if(prevTerm.equals(" ") || nextTerm.equals(" "))
        {
            return "@";
        }
        if(!prevTerm.contains(".txt") && !nextTerm.contains(".txt"))
        {
            for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
             if(prevTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   prevMatch = TokenWithFreqDocList.get(j).DocsName;
               }
             if(nextTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {
                   nextMatch = TokenWithFreqDocList.get(j).DocsName;
               }
                  
         }
          Collection<String> similarDocName = new HashSet<String>(prevMatch);
          similarDocName.retainAll(nextMatch);
          ArrayList <String> Result = new ArrayList<String>(similarDocName);
          for (String s : Result)
          {
              output +="@"+s+"@";
          }
              return output;
        }
        else if(!prevTerm.contains(".txt") && nextTerm.contains(".txt"))
        {
            for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
             if(prevTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   prevMatch = TokenWithFreqDocList.get(j).DocsName;
               }
             
         }
          for (String s : prevMatch)
          {
              if(nextTerm.contains(s))
              output +="@"+s+"@";
          }
     
              return output;
        }
        else if(prevTerm.contains(".txt") && !nextTerm.contains(".txt"))
        {
            for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
             if(nextTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   nextMatch = TokenWithFreqDocList.get(j).DocsName;
               }
             
         }   
          for (String s : nextMatch)
          {
              if(prevTerm.contains(s))
              output +="@"+s+"@";
          }  
             return output;
        }
        else if(prevTerm.contains(".txt") && nextTerm.contains(".txt"))
        {
            List<String> prev = new ArrayList<String>(Arrays.asList(prevTerm.split(" ")));
            List<String> next= new ArrayList<String>(Arrays.asList(nextTerm.split(" ")));
            
            Collection<String> similarDocName = new HashSet<String>(prev);
            similarDocName.retainAll(next);
            ArrayList <String> Result = new ArrayList<String>(similarDocName);
          for (String s : Result)
          {
              output +="@"+s+"@";
          }

              return output;
        }
        return output;   
    }
    public static String ProcessOrOp(String prevTerm,String nextTerm){
        ArrayList <String> prevMatch = new ArrayList<String>();
        ArrayList <String> nextMatch = new ArrayList<String>();
        ArrayList <String> Result = new ArrayList<String>();
        String output = new String();

        if(!prevTerm.contains(".txt") && !nextTerm.contains(".txt"))
        {
             for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
             if(prevTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   Result.addAll(TokenWithFreqDocList.get(j).DocsName);
               }
             if(nextTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {
                   Result.addAll(TokenWithFreqDocList.get(j).DocsName);
               }
         }  
          Set<String> hs = new HashSet<>();
          hs.addAll(Result);
          Result.clear();
          Result.addAll(hs);          
           for (String s : Result)
           {
               output +="@"+s+"@";
           }
           return output;
        }
        else if(prevTerm.contains(".txt") && !nextTerm.contains(".txt"))
        {
              for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
               if(nextTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   Result.addAll(TokenWithFreqDocList.get(j).DocsName);
               }
         }
              output +="@"+prevTerm+"@";
              for (String s : Result)
           {
              if(!output.contains(s))

              output +="@"+s+"@";
           }
              return output;
        }
        else if(!prevTerm.contains(".txt") && nextTerm.contains(".txt"))
        {
              for(int j = 0;j<TokenWithFreqDocList.size();j++)
         {
               if(prevTerm.equals(TokenWithFreqDocList.get(j).getName()))
               {          
                   Result.addAll(TokenWithFreqDocList.get(j).DocsName);
               }
         }
              output +="@"+nextTerm+"@";
              for (String s : Result)
           {
              if(!output.contains(s))

              output +="@"+s+"@";
           }
              return output;
        }
        else if(prevTerm.contains(".txt") && nextTerm.contains(".txt"))
        {
             List<String> next= new ArrayList<String>(Arrays.asList(nextTerm.split("@")));
             output += "@"+prevTerm +"@";
              for (String s : next)
           {
              if(!output.contains(s))
    
              output +="@"+s+"@";
           } 
              return output;
        }   
        return output;        
    }
    
    private static void removeAdditionalSpaces(ArrayList<String> lst_terms){
       lst_terms.removeAll(Arrays.asList(null,""));
       
   }
    
    
    public static void main(String[] args) {
        
        //Tokenization and posting list of files
       // ArrayList <Tokenes> AllTokens = invertedModel("Asmaa.txt","Esraa.txt","Aml.txt","Hend.txt");
        
        String query = "Asmaa and not (Asmaa and not (Amal and Tarek)) or (Tarek or Esraa)";
        
        //Posting List of query
        //QueryPostingList(query,AllTokens);   
        
        //ArrayList <String> words = new ArrayList<String>();
        
        //words = QueryTokinization("( asmaa and ( Mostafa and Mohamed ) and  ( esraa and esraa )  ) or not ( not  Asmaa )");
        
        if(ISValidQuery(query))
        {
            if(ExecuteQuery(0,"") == " ")
            {
                System.out.println("No Result Found");
            }
            else
            {
                System.out.println(ExecuteQuery(0,""));
            }
        }
        else
        {
             System.out.println("Not valid query");
        }
    }
        
}
