/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invertedindexmodel;

import java.util.ArrayList;

public class Tokenes {
    String Name;
    int Frequency;
    String Doc_name;
    int Doc_id;
    ArrayList<Integer> DocsId = new ArrayList<Integer>();
    public ArrayList<String>DocsName = new ArrayList<String>();
     public String getName() {
        return Name;
    }
    
}
