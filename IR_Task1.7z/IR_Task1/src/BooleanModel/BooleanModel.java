/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BooleanModel;

import GUI.BM_IncMatrix;
import GUI.SharedFrame;
import static com.sun.glass.ui.Cursor.setVisible;
import static java.lang.System.exit;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author Amal Tarek
 */
public class BooleanModel {
    
    private  ArrayList<String> TermsBainryVector;
    private  String[] QueryTerms;
    private IncidenceMatrix IncMat;

    public IncidenceMatrix getIncMat() {
        return IncMat;
    }
    private QueryChecker queryCheck;
    private String Result;
    private int DocsSize = 0 ;

    public int getDocsSize() {
        return DocsSize;
    }

    public void setDocsSize(int DocsSize) {
        this.DocsSize = DocsSize;
    }

    public String getResult() {
        return Result;
    }

    public void setResult(String Result) {
        this.Result = Result;
    }
    
    public BooleanModel(IncidenceMatrix IncMat ,QueryChecker queryCheck, String query){
        setIncMat(IncMat);
        setDocsSize(IncMat.getFile().getLstDocs().size());
        setQueryTerms(query.split(""));
        setQueryCheck(queryCheck);
        TermsBainryVector = new ArrayList<String>();
    }

    public ArrayList<String> getTermsBainryVector() {
        return TermsBainryVector;
    }

    public void setTermsBainryVector(ArrayList<String> TermsBainryVector) {
        this.TermsBainryVector = TermsBainryVector;
    }

    public void setQueryTerms(String[] QueryTerms) {    
        this.QueryTerms = QueryTerms;
    }

    public void setQueryCheck(QueryChecker queryCheck) {
        this.queryCheck = queryCheck;
    }

    public void setIncMat(IncidenceMatrix IncMat) {
        this.IncMat = IncMat;
    }
    
    //----------- Complex Query ------------- //
    // Count Brackets and save in array
    private static int counter = -1 ;
    private String[] TmpExpr = new String[queryCheck.getCounteropen()];
    
    /**
     * ExecuteBrackets first in Recursion Function take expr then call execute expr
     * @param i
     * @param expr
     * @return Result
     */
    public String ExecuteQuery(int i, String expr){
       if(i == QueryTerms.length){
           if(expr != "") 
                return ExecuteExpr(expr);
       }
       else if(QueryTerms[i].equals(")") ){
           expr = ExecuteExpr(expr) + " ";
           if(TmpExpr[counter]!= null)
               expr = TmpExpr[counter] + expr ;               
           counter--;
       }else if(QueryTerms[i].equals("(")){
           counter++;
            if(expr != ""){ // Nested Parenthesis store last parent hesis in variable
                TmpExpr[counter] = expr + " ";
                expr = ""; 
            }
       }else {
           expr += QueryTerms[i];
       }
       return ExecuteQuery(++i,expr);
    } 
    
    
    /**
     * Execute Expression ( not and or ) and return result or catch error
     * @param expr
     * @return 
     */
    public String ExecuteExpr(String expr){
        ArrayList<String> lst_terms= new ArrayList<String>(Arrays.asList(expr.split(" ")));
        removeAdditionalSpaces(lst_terms);
        try{
        for (int i = 0; i < lst_terms.size(); i++) {
             if(lst_terms.get(i).equalsIgnoreCase("NOT") && !lst_terms.get(i+1).equals("")){
                lst_terms.remove(i);
                expr = ProcessNotOp(lst_terms.get(i).trim());
                lst_terms.set(i, expr);
                
            }
        }
        for (int j = 0; j < lst_terms.size(); j++) {
             if(lst_terms.get(j).equalsIgnoreCase("AND") && !lst_terms.get(j-1).equals("") && !lst_terms.get(j+1).equals("")){
                lst_terms.remove(j);
                String prevTerm = lst_terms.get(--j).trim();
                lst_terms.remove(j);
                String nextTerm = lst_terms.get(j).trim();
                expr = ProcessAndOp(prevTerm,nextTerm);
                lst_terms.set(j, expr);
                
            } 
        }
        for (int k = 0; k < lst_terms.size(); k++) {
             if(lst_terms.get(k).equalsIgnoreCase("OR") && !lst_terms.get(k-1).equals("") && !lst_terms.get(k+1).equals("")){
                lst_terms.remove(k);
                String prevTerm = lst_terms.get(--k).trim();
                lst_terms.remove(k);
                String nextTerm = lst_terms.get(k).trim();
                expr = ProcessOrOp(prevTerm,nextTerm);
                lst_terms.set(k, expr);
                
            } 
        }
        }catch(Exception ex){
            System.out.println("Invalid Query");
            JOptionPane.showMessageDialog(SharedFrame.H_panel, "Invalid Query", "Error", JOptionPane.ERROR_MESSAGE);
            exit(1);
        }
        
      /*  if (lst_terms.size()!=1 || !lst_terms.get(0).matches("[01]+")) {
            lst_terms.set(0,"Invalid ");
        }*/
       return String.join("", lst_terms); 
    }
    
    /**
     * Execute Not Operation
     * @param term
     * @return 
     */
    public String ProcessNotOp(String term){
        String vector = getBinaryVector(term);
        String Result="";
        for(int i=0; i < vector.length();i++){
            if(vector.charAt(i) == '1'){
                Result+="0";
            }else{
                Result+="1";
            }
        }
        queryCheck.CheckTerms(Result);
        return Result;
         
    }
    
    /**
     * Execute And Operation take two terms get Vectors then return result
     * @param prevTerm
     * @param nextTerm
     * @return 
     */
    public String ProcessAndOp(String prevTerm,String nextTerm){
        String prevVector = getBinaryVector(prevTerm);
        String nextVector = getBinaryVector(nextTerm);
        String Result="";
        for(int i=0; i < prevVector.length() && i <  nextVector.length();i++){
            if(prevVector.charAt(i) == '1' && nextVector.charAt(i) == '1'){
                Result+="1";
            }else{
                Result+="0";
            }
        }
        queryCheck.CheckTerms(Result);
        return Result;
         
    }
    
    /**
     * Execute Or Operation at the same way of and
     * @param prevTerm
     * @param nextTerm
     * @return 
     */
    public String ProcessOrOp(String prevTerm,String nextTerm){
        String prevVector = getBinaryVector(prevTerm);
        String nextVector = getBinaryVector(nextTerm);
        String Result="";
        for(int i=0; i < prevVector.length() && i <  nextVector.length();i++){
            if(prevVector.charAt(i) == '0' && nextVector.charAt(i) == '0'){
                Result+="0";
            }else{
                Result+="1";
            }
        }
        queryCheck.CheckTerms(Result);
        return Result;
         
    }
    
    /**
     * Get Binary Vector for each Term from Incidence Matrix
     * @param term
     * @return 
     */
     public String getBinaryVector(String term){
         if(term.matches("[01]+"))
             return term;
         else if(IncMat.getIncMat().containsKey(IncMat.StyleTerm(term))){
            String BainryVector = IncMat.getIncMat().get(IncMat.StyleTerm(term));
            String Term = IncMat.StyleTerm(term) + " " + BainryVector;
            if(!TermsBainryVector.contains(IncMat.StyleTerm(Term))){
                TermsBainryVector.add(IncMat.StyleTerm(Term));
            }      
            return BainryVector;
         }     
         else{
             //System.out.println("No Search Result found");
              return "";
         }  
     }
    
    /**
     * Get Matched Documents of Result
     * @param Result
     * @return 
     */ 
    public String getMatchedDocuments(String Result){
        
        String MatchedDocs = "";
        try{
        String[] aryOfChar = Result.split("");
        int i ;
        for(i=0 ; i<aryOfChar.length ; i++){
            if(aryOfChar[i].equals("1"))
                MatchedDocs += IncMat.getFile().getLstDocs().get(i).getDocName() + "   ";
                
        }
        }catch(Exception ex){
            System.out.println("Invalid Query");
            JOptionPane.showMessageDialog(SharedFrame.H_panel, "Invalid Query", "Error", JOptionPane.ERROR_MESSAGE);
            exit(1);
        }
        return MatchedDocs;
    }
    
    /**
     * Remove any  null term in Array list
     * @param lst_terms 
     */
    private void removeAdditionalSpaces(ArrayList<String> lst_terms){
       lst_terms.removeAll(Arrays.asList(null,""));
       
   }
}

