/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BooleanModel;

import java.io.*;
import java.util.*;

/**
 *
 * @author Amal Tarek
 */
public class FileHandling {
    private File[] FilesPath;
    private ArrayList<Document> LstDocs;
    private static List<String> StopWords = Arrays.asList("a", "able", "about", "something" , "tell",
                "across", "after", "all", "almost", "also", "am", "among", "an", "try",
                "and", "any", "are", "as", "at", "be", "because", "been", "but", "thing",
                "by", "can", "cannot", "could", "dear", "did", "do", "does", "come",
                "either", "else", "ever", "every", "for", "from", "get", "got", "mean",
                "had", "has", "have", "he", "her", "hers", "him", "his", "how", "much",
                "however", "i", "if", "in", "into", "is", "it", "its", "just", "very",
                "least", "let", "like", "likely", "may", "me", "might", "most", "ill",
                "must", "my", "neither", "no", "nor", "not", "of", "off", "often", "up",
                "on", "only", "or", "other", "our", "own", "rather" , "said", "say", "came",
                "says", "she", "should", "since", "so", "some", "than", "that", "way",
                "the", "their", "them", "then", "there", "these", "they", "this", "made",
                "to", "too", "us", "wants", "was", "we", "were", "goes", "going", "make",
                "what", "when", "where", "which", "while", "who", "whom", "why", "without",
                "will", "with", "would", "yet", "you", "your", "more", "doesnt", "isnt");
    
    public FileHandling(File[] Files){
        setFilesPath(Files);
        PrepareDocs();
    }

    public File[] getFilesPath() {
        return FilesPath;
    }

    public void setFilesPath(File[] FilesPath) {
        this.FilesPath = FilesPath;
    }

    public ArrayList<Document> getLstDocs() {
        return LstDocs;
    }

    public void setLstDocs(ArrayList<Document> LstDocs) {
        this.LstDocs = LstDocs;
    }
    
    /**
     * Create Documents with file name and Content and ID
     */
    private void PrepareDocs(){
        LstDocs = new ArrayList<Document>();
        int i =1;
        for(File file : getFilesPath()){
            LstDocs.add(new Document(readFile(file),getFileName(file.toString()),i));
            i++;
        }   
    }
    
    /**
     * Read File and return Content of file after remove any special words or additional spaces
     * @param file
     * @return 
     */
    private static String readFile(File file)
    {
        String fileContent = "";
        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader buffRe = new BufferedReader(fileReader);
             String line;
                while ((line = buffRe.readLine()) != null) {
                   fileContent += line.replaceAll("[^a-zA-Z]", " ");
                   fileContent +=" ";
                }
            fileReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println("File " + file + " Not Found");                
        }
        catch(IOException ex) {
            ex.printStackTrace();
        }
       return fileContent.replaceAll("\\s+", " ").trim();
    }
    
    /**
     * Get The File Name from The path without extension
     * @param file
     * @return FileName
     */
    private static String getFileName(String file)
    {
       return file.substring(file.lastIndexOf("\\")).replace(".txt", "").replace("\\","");
    }
    
    /**
     * removes all stop words from Content Array and return Array
     * @param Content
     * @return 
     */
    public String[] RemoveStopsWords(String[] Content)
    {
        List<String> terms = new ArrayList<String>();
        
        for (String term : Content)
        {
            if (!StopWords.contains(term) && !term.equals(""))
            {
                terms.add(term);
            }
        }
        Content = new String[terms.size()];
        return terms.toArray(Content);
    }   
}
