/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BooleanModel;

/**
 *
 * @author Amal Tarek
 */
public class Document {
    private String docContent;
    private String docName;
    private final int docId;

    public Document(String docContent,String docName,int docId){
        this.docId = docId;
        this.docContent = docContent;
        this.docName = docName;
    }

    public String getDocContent() {
        return docContent;
    }

    public void setDocContent(String docContent) {
        this.docContent = docContent;
    }
    
    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }
    
    public int getId() {
        return docId;
    }
}
