/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BooleanModel;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Amal Tarek
 */
public class Main {
    
    // i'll Convert it to GUI 
    public void start(){   
        
        File[] lstFiles = new File("src\\IR Documents\\").listFiles(); 
        IncidenceMatrix IncMat = new IncidenceMatrix(lstFiles);
        IncMat.displayInsienceMatrix();
        System.out.println("\nEnter your Query: ");
        Scanner scanner = new Scanner(System.in);
        String Query = scanner.nextLine();
        QueryChecker queryCheck = new QueryChecker(Query);
        if(!queryCheck.ValidRoundBrackets() || !queryCheck.ValidQuery()){
            System.out.println("Please, Enter a Valid Query");
            start();
        }
        BooleanModel bm = new BooleanModel(IncMat,queryCheck,queryCheck.getQuery());
        String Result = bm.ExecuteQuery(0, "");
        if(!queryCheck.CheckError() || !queryCheck.CheckResult(Result,IncMat)){
            System.out.println("No Search Result Found");
            start();
        }
        System.out.println("Binary Vector for Each Term :");
        displayBainryVectors(bm.getTermsBainryVector());
        System.out.println("Result is " + Result);
        if(bm.getMatchedDocuments(Result).length()!=0)
            System.out.println("Matched Documents is "+ bm.getMatchedDocuments(Result));
        else
            System.out.println("There's No matched Document");
        
    }
    
    /**
     * Convert it to GUI
     * @param QueryTerms 
     */
    public static void displayBainryVectors(ArrayList<String> QueryTerms){
        for(String term : QueryTerms){
            System.out.println(term);
        }
    }
}
