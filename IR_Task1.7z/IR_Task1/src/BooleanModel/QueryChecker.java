/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BooleanModel;

/**
 *
 * @author Amal Tarek
 */
public class QueryChecker {
    
    private String query;
    private static int Error;
    private static int counteropen;

    public QueryChecker(String query) {
        setQuery(query);
        setError(0);
        setCounteropen(0);
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {    
        this.query = query.replaceAll("\\s+", " ");
    }

    public static int getError() {
        return Error;
    }

    public static void setError(int Error) {
        QueryChecker.Error = Error;
    }

    public static int getCounteropen() {
        return counteropen;
    }

    public static void setCounteropen(int counteropen) {
        QueryChecker.counteropen = counteropen;
    }
    
    
    /**
     * Return if Parent Brackets is valid or is not
     * @return 
     */
     public boolean ValidRoundBrackets(){
        String[] aryOfChar = query.split("");
        
        int counterclose = 0;
        for(int i = 0; i<aryOfChar.length; i++){
            if(aryOfChar[i].equals("("))
                counteropen++;
            else if(aryOfChar[i].equals(")"))
                counterclose++;
        }
        if(counteropen==counterclose)
            return true;
        else
            return false;
    }
     
    /**
     * check if query is string or () or spaces any thing else return false
     * @return 
     */
    public boolean ValidQuery(){  
        if(query.matches("[a-zA-Z() ]+"))
            return true;
        else
            return false;
    }  
    
    /**
     * check if binary vector is null then the term doesn't exist
     * @param BainryVector 
     */
    public void CheckTerms(String BinaryVector){ 
        if(BinaryVector.equals(""))
           Error++;
    } 
    
    public boolean CheckError(){ 
        if(Error!=0)
            return false;
        else
            return true;
    }  
    
    /**
     * Check Result if not 0 or 1 then The Query is invalid
     * @param Result
     * @return 
     */
    public boolean CheckResult(String Result, IncidenceMatrix IncMat){  
        return (Result.matches("[01]+") && Result.length()== IncMat.getFile().getLstDocs().size());
    }  
    
}
