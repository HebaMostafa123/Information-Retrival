/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BooleanModel;



import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Amal Tarek
 */
public class IncidenceMatrix {
    
    private HashMap<String,String> IncMat;
    private FileHandling file;
    
    public IncidenceMatrix(File[] Files){
        file = new FileHandling(Files);
        createIncidenceMatrix();
    }

    public HashMap<String, String> getIncMat() {
        return IncMat;
    }

    public void setIncMat(HashMap<String, String> IncMat) {
        this.IncMat = IncMat;
    }

     public FileHandling getFile() {
        return file;
    }
    
    /**
     * Create Matrix from Documents
     */
    private void createIncidenceMatrix(){
        IncMat =new HashMap<String,String>();
        ArrayList<Document> lstDocs = file.getLstDocs();
        for(int i=0; i < lstDocs.size() ; i++){
            String[] terms = lstDocs.get(i).getDocContent().split(" ");
            terms = file.RemoveStopsWords(terms);
            for (String Term : terms) {
                if(!IncMat.containsKey(StyleTerm(Term))){
                    IncMat.put(StyleTerm(Term), repeatZero(i)+"1");
                }else{
                    if(!(i+1 == IncMat.get(StyleTerm(Term)).length()))
                        IncMat.put(StyleTerm(Term), IncMat.get(StyleTerm(Term)) +"1");
                }
                   
            }
            for (String Term : IncMat.keySet()) {
                if(IncMat.get(StyleTerm(Term)).length() != (i+1)){
                    IncMat.put( StyleTerm(Term), IncMat.get(StyleTerm(Term)) +"0");
                }

            }
        }
    }
    
    /**
     * Repeat Zero as number of documents if the term is new
     * @param numofTimes
     * @return 
     */
    private String repeatZero(int numofTimes){
        String Zeros ="";
        for (int i = 0; i < numofTimes; i++) {
            Zeros += "0";      
    }
       return Zeros; 
    }
    
    /**
     * display Matrix Convert it to GUI
     */
    public void displayInsienceMatrix(){
        System.out.print("\t\t");
        ArrayList<Document> lstDocs = file.getLstDocs();
        for(int i=0; i < lstDocs.size() ; i++){
            System.out.print( "\t"+lstDocs.get(i).getDocName()+"\t");
        }
        for (String Term : IncMat.keySet()) {
            String[] bainryVector = IncMat.get(Term).split("");
            System.out.print("\n  "+Term+"  :\t");
            for(int i =0; i < bainryVector.length ; i++)
                System.out.print("\t"+bainryVector[i]+"\t");
        }   
    }
    
    /**
     * Style Term by making first letter Capital and other's small
     * @param input
     * @return 
     */
    public String StyleTerm(String input){
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }
}
